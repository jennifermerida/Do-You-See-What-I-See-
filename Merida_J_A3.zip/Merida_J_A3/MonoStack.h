// Full name: Jennifer Merida
// Student ID: 2429914
// Chapman email: merida@chapman.edu
// Course number and section: CPSC-350-04
// Assignment or exercise number: Programming Assignment 3: Do You See What I See?

#ifndef MONOSTACK_H
#define MONOSTACK_H
#include <iostream>
#include <stdexcept>
using namespace std;

template <typename T>
// template class for monotonic stack
class MonoStack{
    private:
        T* stackArr;            // our array to hold heights
        int maxSize;            // max num of things that can fit in the stack
        int top;                // index of the current top of the stack
        int count;              // will keep track of num of items currently in the stack 
        char stackOrder;        // will keep track of i for increasing and d for decreasing
    public: 
        MonoStack(int iSize, char o);    // constructor
        ~MonoStack();                    // desctructor
        void push (T c);        // add character to the top of the stack
        T pop();             // will remove top character from stack and return it
        T peek()const;            // will return but NOT remove top char from stack
        bool isEmpty()const;         // true is ctack is empty, false otherwise
        bool isFull()const;          // true if stack is full, false other wise
        int size()const;             // will return size of stack as an integer
};

//define constructor 
template <typename T>
MonoStack<T>::MonoStack (int iSize, char o){
    if (o != 'i' && o != 'd'){
        throw invalid_argument("Invalid order type :(");
    }
    // initialize stack
    maxSize = iSize;                // make maxSize the inital size (iSize) of the array to me memory effcient
    stackArr = new T[maxSize];      // dynamically allocate an array 
    top = -1;                       // make top -1 so that incrementing later makes sense (-1 + 1 = 0). first element will start at index[0].
    count = 0;                      // zero things in the stack
    stackOrder = o;                 // o represents the order in which the stack is moving. increasing or decreasing
}

// define destructor
template <typename T>
MonoStack<T>::~MonoStack() {     
    delete[] stackArr;              // delete dynamically allocated array
    stackArr = nullptr;             // this stack will now point to nothing (null)
}

// define push function
template <typename T>
void MonoStack<T>::push(T c){   
    if (isFull()){
        // create a temporary array to store all the elements, while we redirect pointers and double the max size of the actual array
        T* temp = new T[maxSize * 2];
        for (int i = 0; i < maxSize; ++i){
            temp[i] = stackArr[i];
        }
        delete[] stackArr;
        stackArr = temp;
        maxSize *= 2;
    }

    // make sure that the stack maintains it's monotonic structure
    if(stackOrder == 'i'){
        while (count > 0 && stackArr[top] > c){
            pop();
        }
    }
    else if(stackOrder == 'd') {
        while (count > 0 && stackArr[top] < c){
            pop();
        }
    }
    count++;
    stackArr[++top] = c;
}

//define pop function 
template <typename T>
T MonoStack<T>::pop(){
    if(isEmpty()){
        throw underflow_error("Underflow error: Can't pop from an empty stack");         // safety check
    } 
    --count;
    return stackArr[top--];  
}

//define peek function 
template <typename T>   
T MonoStack<T>::peek()const {
    if(isEmpty()){
        throw underflow_error("Underflow error: Can't peek at an empty stack");      // safety check
    } 
    return stackArr[top];
}

//define isEmpty function
template <typename T>
bool MonoStack<T>::isEmpty()const {
    return (count == 0);
}

//define isFull function
template <typename T>
bool MonoStack<T>::isFull()const {
    return (count == maxSize);
}

//define size function 
template <typename T>
int MonoStack<T>::size() const {
    return count;
}
#endif