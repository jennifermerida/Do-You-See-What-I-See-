Full name: Jennifer Merida
Student ID: 2429914
Chapman email: merida@chapman.edu
Course number and section: CPSC-350-04
Assignment or exercise number: Programming Assignment 3: Do You See What I See?

Source Files: MonoStack.h, SpeakerView.h, SpeakerView.cpp, main.cpp, input_file.txt

Sources:
- Zybooks
- Lecture Notes:
- Dr.EEL's C++ Notion Page
- CHATGPT
- Youtube

Links I used:
- https://liuzhenglaichn.gitbook.io/algorithm/monotonic-stack
- https://docs.oracle.com/cd/E60778_01/html/E60763/z4000ac020351.html#:~:text=Underflow%20occurs%2C%20roughly%20speaking%2C%20when that%20is%20larger%20than%20usual
- https://www.youtube.com/watch?v=3j6vi5G86Gg 
- https://www.w3schools.com/cpp/cpp_exceptions.asp
- https://www.youtube.com/watch?v=JdEWCntMTN0 
- https://learn.microsoft.com/en-us/cpp/standard-library/underflow-error-class?view=msvc-170

Errors: 
- None that I'm aware of. Once I got it to output exactly what was on the assignment intructions, I did it twice more and the outputs
  were identical. 

Instructions to run program:
- To compile: g++ -o myProgram main.cpp SpeakerView.cpp  
- To run: ./myProgram input_file.txt