// Full name: Jennifer Merida
// Student ID: 2429914
// Chapman email: merida@chapman.edu
// Course number and section: CPSC-350-04
// Assignment or exercise number: Programming Assignment 3: Do You See What I See?

#include "SpeakerView.h"
#include <sstream>
#include <stack>

// Constructor to read from input file
SpeakerView::SpeakerView(const string & filename) {
    readFile(filename);
}

// Destructor 
SpeakerView::~SpeakerView() {
    for(int i = 0; i < row; ++i) {
        delete [] seatHeights[i];       // deletes the allocated memory
    }
    delete [] seatHeights;              // deletes the pointers to the rows
}

void SpeakerView::guestVisibility() {
    for(int j = 0; j < cols; ++j) {
        /// BEGIN CODE FROM CHAT GPT, PROMPT ASKED: "How can I calculate which guest (in each column) can see by using a stack to keep track of them? From bottom up."///
        MonoStack<double> visibilityStack(row, 'd');  // monotonic stack to keep track of guests who have visibility
        // Process each row in the current column (from bottom to top)
        for (int i = row - 1; i >= 0; --i) {
            while (!visibilityStack.isEmpty() && visibilityStack.peek() <= seatHeights[i][j]) {
                visibilityStack.pop();  // Pop shorter heights
            }
            visibilityStack.push(seatHeights[i][j]);  // Push the current height
        }
        /// END CODE FROM CHAT GPT ///

        // print the results in assigment format
        cout << "In column " << j << " there are " << visibilityStack.size() << " that can see. Their heights are: ";

        // calualate the number of visible heights - for assigment output format
        int visibleCount = visibilityStack.size();
        
        // in case no one can see... it skips printing
        if (visibleCount == 0) {
            cout << "." << endl;
            continue;
        }

        // to store guests who can have visibility
        double visibleHeights[visibleCount];
        
        // pop the heights into the array
        int index = 0;
        while (!visibilityStack.isEmpty()) {
            visibleHeights[index++] = visibilityStack.pop();
        }

        // bubble sort to fit format from assignment
        for (int i = 0; i < visibleCount - 1; ++i) {
            for (int j = 0; j < visibleCount - i - 1; ++j) {
                if (visibleHeights[j] > visibleHeights[j + 1]) {
                    double temp = visibleHeights[j];        // swap heights
                    visibleHeights[j] = visibleHeights[j + 1];
                    visibleHeights[j + 1] = temp;
                }
            }
        }

        // will print the now sorted heights and add "inches" and "," inbetween
        for (int i = 0; i < visibleCount; ++i) {
            if (i != 0) cout << ", ";  // add a comma
            cout << visibleHeights[i] << " inches";
        }
        cout << "." << endl;
    }
}

// will display the results 
void SpeakerView::displayResults() const {
    for(int i = 0; i < row; i++) {
        for(int j = 0; j < cols; j++) {
            cout << seatHeights[i][j] << " ";       // display the seat heights
        }
        cout << endl;
    }
}

void SpeakerView::readFile(const string & filename) {
    ifstream file(filename);    // ifstream to read from input file
    if (!file.is_open()) {      // will check if file opened properly, if not it throws an error :D
        throw runtime_error("Error: Failed to open the file: " + filename);     
    }

    string line;                  // to hold 'begin'
    bool readingData = false;     // will let us know when we are past "begin" in the input file 
    int currentRow = 0;     // to keep track of curent row 

    // this is the first reading the program will do. this one will look out for 'begin' and 'end'
    // the program will think the first line is rows or cols already (thats not true), so this makes sure that it skips the very first and last line of the input file
    while (getline(file, line)) {
        if (line == "BEGIN") {
            readingData = true;     // this will start reding after the line 'begin' 
            continue;               // will continue to the next 
        } else if (line == "END") {
            break;                  // when it reads 'end' it will break (stop) 
        }
        if (readingData) {          // makes sure we are between 'begin' and 'end'
            stringstream s(line);   // takes current line into stringstream (this was an idea (to use <sstream>) i got from chatgpt, but not the actual code.)
            double height;
            int col = 0;            // will count how many heights are in each row 

            while (s >> height) {   // will look for heights 
                col++;              // increase col count for how many heights are found
            }

            if (currentRow == 0) {
                cols = col;  // Set the number of columns for the first row
            }
            currentRow++;
        }
    }

    row = currentRow;

    // allocates memory for seat heights
    seatHeights = new double*[row];
    for (int i = 0; i < row; ++i) {
        seatHeights[i] = new double[cols];
    }

    // Reset file stream to read data again
    file.close();
    file.open(filename);

    readingData = false;
    currentRow = 0;

    // this second pass is to read the actual data in the input file. the 
    while (getline(file, line)) {
        if (line == "BEGIN") {
            readingData = true;
            continue;
        } else if (line == "END") {
            break;
        }

        // if we are inbetween 'begin' and 'end'
        if (readingData) {
            stringstream s(line);
            double height;
            int col = 0;

            while (s >> height) {           // get the heights 
                seatHeights[currentRow][col++] = height;        // will store the heights
            }
            currentRow++;
        }
    }
    file.close();       // close the file!!!
}