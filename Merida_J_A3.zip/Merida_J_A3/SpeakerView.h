// Full name: Jennifer Merida
// Student ID: 2429914
// Chapman email: merida@chapman.edu
// Course number and section: CPSC-350-04
// Assignment or exercise number: Programming Assignment 3: Do You See What I See?

#ifndef SPEAKERVIEW_H
#define SPEAKERVIEW_H
#include <iostream>
#include <fstream>
#include <stdexcept>
#include "MonoStack.h"
using namespace std;

class SpeakerView {
    private:
        int row, cols;          // num of rows and cols int the seatching chat
        double** seatHeights;   // to store seat heights
        void readFile(const string & filename);      // to read input file 
    public:
        SpeakerView(const string & filename);   // constructor
        ~SpeakerView();                         // destructor
        void guestVisibility();                 // to calculate who can see the speaker 
        void displayResults()const;             // to display final results 
};
#endif
