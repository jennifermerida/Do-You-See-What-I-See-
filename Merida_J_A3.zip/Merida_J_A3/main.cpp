// Full name: Jennifer Merida
// Student ID: 2429914
// Chapman email: merida@chapman.edu
// Course number and section: CPSC-350-04
// Assignment or exercise number: Programming Assignment 3: Do You See What I See?

#include <iostream>
#include "SpeakerView.h"
using namespace std;

int main(int argc, char* argv[]) {
    if (argc != 2) {        // will make sure that the command line recieves correct num of inputs
        cerr << "Usage: " << argv[0] << " <input_file>" << endl;    // error if there is no input file given :D
        return 1;
    }
    try {
        SpeakerView seatArrangement(argv[1]);       // creates obj and takes the inputfile as an argument
        seatArrangement.guestVisibility();          // determine which guests can see the speaker
    } 
    /// BEGIN CODE FROM CHAT GPT, PROMPT ASKED: "How can I complete this try catch so that if something goes wrong it'll catch it and print an error"///
    catch (const exception & e) {
        cerr << "Error: " << e.what() << endl;
        return 1;
    /// END CODE FROM CHAT GPT ///
    }
    return 0;
}